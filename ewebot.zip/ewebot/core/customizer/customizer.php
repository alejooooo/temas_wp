<?php

use Elementor\Core\Kits\Controls\Repeater as Global_Style_Repeater;
use Elementor\Repeater;
use \GT3\ThemesCore\Customizer;

require_once __DIR__.'/defaults.php';
if(!class_exists('\GT3\ThemesCore\Customizer')) {
	return;
}

Customizer::add_panel(
	'theme_options', array(
		'title'    => 'Theme Options',
		'priority' => 2
	)
);
require_once __DIR__.'/section/general.php';
require_once __DIR__.'/section/preloader.php';
require_once __DIR__.'/section/page_title.php';
require_once __DIR__.'/section/blog.php';
require_once __DIR__.'/section/post_types.php';
require_once __DIR__.'/section/sidebar.php';
require_once __DIR__.'/section/google_map.php';
require_once __DIR__.'/section/optimization.php';

if(class_exists('WooCommerce')) {
	require_once __DIR__.'/section/shop_global_settings.php';
	require_once __DIR__.'/section/shop_single_product.php';
	require_once __DIR__.'/section/shop_page_title.php';
}

/* Convert Fields */
add_filter('gt3/core/customizer/elementor/convert_fields', array(
	/* Fonts */
	'main-font'      => array(
		'font'  => array( 'field' => 'system_typography', 'id' => 'theme-main' ),
		'color' => array( 'field' => 'system_colors', 'id' => 'theme-content-color' ),
	),
	'secondary-font' => array(
		'font'  => array( 'field' => 'system_typography', 'id' => 'theme-secondary' ),
		'color' => array( 'field' => 'system_colors', 'id' => 'theme-secondary-color' ),
	),
	'header-font'    => array(
		'font'  => array( 'field' => 'system_typography', 'id' => 'theme-headers' ),
		'color' => array( 'field' => 'system_colors', 'id' => 'theme-header-font-color' ),
	),
	'h1-font'        => array(
		'font' => 'h1_typography',
	),
	'h2-font'        => array(
		'font' => 'h2_typography',
	),
	'h3-font'        => array(
		'font' => 'h3_typography',
	),
	'h4-font'        => array(
		'font' => 'h4_typography',
	),
	'h5-font'        => array(
		'font' => 'h5_typography',
	),
	'h6-font'        => array(
		'font' => 'h6_typography',
	),
	'modern_shop_main-font' => array(
		'font'  => array( 'field' => 'system_typography', 'id' => 'theme-modern-shop-main' ),
	),
	'modern_shop_header-font' => array(
		'font'  => array( 'field' => 'system_typography', 'id' => 'theme-modern-shop-headers' ),
	),
	/* Colors */
	'theme-custom-color'        => array(
		'color' => array( 'field' => 'system_colors', 'id' => 'theme-custom-color' )
	),
	'theme-custom-color2'       => array(
		'color' => array( 'field' => 'system_colors', 'id' => 'theme-custom-color2' )
	),
	'theme-custom-color-start'       => array(
		'color' => array( 'field' => 'system_colors', 'id' => 'theme-custom-color-start' )
	),
	'theme-custom-color2-start'       => array(
		'color' => array( 'field' => 'system_colors', 'id' => 'theme-custom-color2-start' )
	),
	'body-background-color'       => array(
		'color' => array( 'field' => 'system_colors', 'id' => 'theme-body-bg-color' )
	),

	/*
				'map-marker-font'         => '',
				'modern_shop_main-font'   => '',
				'modern_shop_header-font' => '',*/

));
